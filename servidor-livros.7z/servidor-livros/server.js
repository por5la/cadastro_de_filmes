//1 inves de https importaremos a biblioteca express
const express = require('express');
const app = express( );
const port = 3000;

//2 definindo retorno para o ednpoint prancipal
app.get('/', (req, res) => {
    res.json({ massage: 'Bem-vindo ao meu servidor Express'
});

//3 Executando servidor
app.listen(port, ( ) => {
    console.log(`Servidor Express Rodando!!!!!!`);
})
});